package acorn

abstract class Expression {
  def execute: Double
}