package adapter

class Adapter extends IThermometer {
  override def getMeanTemperature(cities: List[String]): Double = {
    var average = 0.0
    val cenTherm = new CenTherm // Using association, the Adapter calls an instance of CenTherm
    
    for (i <- 0 until cities.length) {
      average += cenTherm.computeTemp(cities(i))
    }

    average *= 1.8
    average += 32.0 // Converts Centigrade to Fahrenheit.
    average /= cities.length
    average
  }
}