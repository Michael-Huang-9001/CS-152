package adapter

object AdapterTest extends App {
  val list = List("Oakland", "Los Angeles", "San Francisco", "Weed")
  val adapter = new Adapter
  println(adapter.getMeanTemperature(list) + " degrees Fahrenheit")
  println("Expected: 47.6 degrees Fahrenheit")
}