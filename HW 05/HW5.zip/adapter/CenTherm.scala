package adapter

/**
 * Example CenTherm class.
 */
class CenTherm {
   // = degrees Centigrade 
   def computeTemp(city: String) = {
     if (city.length < 5)
       18.0
     else if (city.length >= 5 && city.length < 8)
       22.0
     else
       24.0
   }
}