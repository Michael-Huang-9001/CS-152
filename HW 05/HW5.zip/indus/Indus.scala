package indus

object Indus extends App {
  val matrix = Description("The Matrix DVD", 15.50, "DVD World")
  val terminator = Description("The Terminator DVD", 13.25, "DVD World")
  val ironman = Description("Ironman DVD", 18.00, "DVD Planet")
  // println(matrixDVD.toString)
  
  var inv = scala.collection.mutable.ArrayBuffer.empty[Item]
  for (i <- 0 until 5)
    inv.append(Item(matrix))
  for (i <- 0 until 3)
    inv.append(Item(terminator))
  for (i <- 0 until 2)
    inv.append(Item(ironman))
  for (i <- inv) {
    println(i.toString)
  }
}