package indus

class Description(text: String, price: Double, supplier: String) {
  override def toString = "Item description: " + text + " | Price: $" + price + " | Supplier: " + supplier
}

object Description {
  def apply(text: String, price: Double, supplier: String) = new Description(text, price, supplier)
}