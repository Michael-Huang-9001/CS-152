package indus

class Item(id: Int, desc: Description) {
  override def toString = "Item ID: " + id + " | " + desc.toString
}

object Item {
  var nextID = 0
  def apply(desc: Description) = {
    nextID += 1
    new Item(nextID, desc)
  }
}