package dnd

object Dungeon {
  val random = new scala.util.Random(System.nanoTime())

  def main(args: Array[String]): Unit = {
    var knight = new Knight("Solace")
    var dragon = new Dragon("Blaster")
    while (knight.health > 0 && dragon.health > 0) {
      knight.attack(dragon)
      if (dragon.health > 0) {
        dragon.attack(knight)
      }
    }
  }
}