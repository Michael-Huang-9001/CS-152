package dnd

class Knight(val name: String) {
  var health = 100
  
  def attack(victim: Dragon) = {
    println(name + " is stabbing " + victim.name + "!")
    val damage = Dungeon.random.nextInt(health) + 1
    if (damage > victim.health)
      victim.health = 0
    else
      victim.health -= damage
    println(victim.name + " has " +  victim.health + " health left!")
  }
}