package dnd

class Dragon(val name: String) {
  var health = 100
  
  def attack(victim: Knight) = {
    println(name + " is flaming " + victim.name + "!")
    val damage = Dungeon.random.nextInt(health) + 1
    if (damage > victim.health) 
      victim.health = 0
    else
      victim.health -= damage
    println(victim.name + " has " +  victim.health + " health left!")
  }
}