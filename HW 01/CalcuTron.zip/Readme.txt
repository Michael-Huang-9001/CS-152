Submission: Michael Huang
ID: 009899747
Section: CS 152 - Section 03
Professor: Jon Pearce

Notes: Please check the comment I wrote for NotFunction in Cranberry.java, thank you.