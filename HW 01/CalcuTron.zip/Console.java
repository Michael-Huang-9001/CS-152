import java.util.*;

class Command {

	private String opcode;
	private List<String> operands;

	public Command(String opcode, List<String> operands) {
		this.opcode = opcode;
		this.operands = operands;
	}

	private String add(List<String> args, Map<String, Integer> env) throws Exception {
		Integer result = 0;
		Integer x = 0;
		for (String arg : args) {
			try {
				x = Integer.parseInt(arg);
			} catch (Exception e) {
				x = env.get(arg);
				if (x == null)
					throw new Exception("undefined variable: " + arg);
			}
			result += x;
		}
		return "" + result;
	}

	private String mul(List<String> args, Map<String, Integer> env) throws Exception {
		Integer result = 1;
		Integer x = 1;
		for (String arg : args) {
			try {
				x = Integer.parseInt(arg);
			} catch (Exception e) {
				x = env.get(arg);
				if (x == null)
					throw new Exception("undefined variable: " + arg);
			}
			result *= x;
		}
		return "" + result;
	}

	private String load(List<String> args, Map<String, Integer> env) throws Exception {
		String key = "";
		String value = "";
		Integer x = 0;
		try {
			key = args.get(0);
			if (!Character.isLowerCase(key.charAt(0))) {
				throw new Exception();
			}
			value = args.get(1);
			x = Integer.parseInt(value);
		} catch (Exception e) {
			if (key.isEmpty()) { // args.get(0) is null
				throw new Exception("no variable to load");
			}
			if (!Character.isLowerCase(key.charAt(0))) { // args.get(0) does not start with a lower case letter
				throw new Exception("variables should start with a lower case letter");
			}
			if (value.isEmpty()) { // args.get(1) is null
				throw new Exception("no value to set");
			}
			x = env.get(args.get(1));
			if (x == null) { // cannot find in environment
				throw new Exception("invalid operand: " + args.get(1));
			}
		}
		env.put(key, x);
		return "done";
	}

	public String execute(Map<String, Integer> env) throws Exception {
		try {
			if (this.opcode.equals("load")) {
				return load(operands, env);
			} else if ("add".equals(this.opcode)) {
				return add(operands, env);
			} else if ("mul".equals(this.opcode)) {
				return mul(operands, env);
			} else {
				if (this.opcode.isEmpty()) {
					throw new Exception("no opcode");
				} else {
					throw new Exception("unrecognized opcode: " + this.opcode);
				}
			}
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}
}

public class Console {
	private Scanner kbd = new Scanner(System.in);
	private Map<String, Integer> env = new HashMap<String, Integer>();

	private List<String> scan(String exp) {
		List<String> tokens = new ArrayList<String>();
		if (exp.isEmpty()) {
			return tokens;
		}
		String[] tokensArray = exp.split("\\s+");
		for (String token : tokensArray) {
			if (!token.isEmpty()) {
				tokens.add(token);
			}
		}
		return tokens;
	}

	private Command parse(List<String> tokens) throws Exception {
		try {
			
			for (String token : tokens) {
				if (!token.matches("[A-Za-z0-9]+")) {
					throw new Exception("input is not alphanumeric");
				}
			}
			String firstToken = tokens.get(0); // load, add, mul
			tokens.remove(0);
			Command command = new Command(firstToken, tokens);
			return command;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}

	// read-execute-print loop
	public void repl() {
		while (true) {
			try {
				System.out.print("-> ");
				String input = kbd.nextLine();
				if (input.equals("quit"))
					break;
				Command cmmd = parse(scan(input));
				System.out.println(cmmd.execute(env));
			} catch (Exception e) {
				System.out.println("Error, " + e.getMessage());
			}
		}
		System.out.println("bye");
	}

	public static void main(String args[]) {
		Console console = new Console();
		console.repl();
	}
}