import java.util.*;

interface Value {

}

interface Expression {
	Value execute(Environment env) throws Exception;
}

// Exception for undefined function calls
abstract class Literal implements Value, Expression {
	public Value execute(Environment env) throws Exception {
		return this;
	}
}

class Number extends Literal {
	private Double value;

	public Number(Double value) {
		this.value = value;
	}

	public String toString() {
		return "" + value;
	}

	public Number add(Number other) {
		return new Number(this.value + other.value);
	}

	public Number sub(Number other) {
		return new Number(this.value - other.value);
	}

	public Number mul(Number other) {
		return new Number(this.value * other.value);
	}

	public Number div(Number other) throws Exception {
		try {
			if (other.value == 0.0) {
				throw new Exception();
			}
			double result = this.value / other.value;
			return new Number(result);
		} catch (Exception e) {
			throw new Exception("Cannot divide by 0");
		}
	}
	// mul, sub, div, etc.
}

class Boole extends Literal {
	private boolean bool;

	public Boole(boolean bool) {
		this.bool = bool;
	}

	public Boole and(Boole bool) {
		return new Boole(this.bool && bool.bool);
	}

	public Boole or(Boole bool) {
		return new Boole(this.bool || bool.bool);
	}

	public Boole not() {
		return new Boole(!this.bool);
	}

	public String toString() {
		return "" + bool;
	}
}

class Text extends Literal {
	private String text;

	public Text(String text) {
		this.text = text;
	}

	public String toString() {
		return this.text;
	}

	public Text append(Text text) {
		return new Text(this.text + text.text);
	}
}

class Name implements Expression {
	private String printName;

	public Name(String printName) {
		this.printName = printName;
	}

	public String toString() {
		return printName;
	}

	public int hashCode() {
		return printName.hashCode();
	}

	public Value execute(Environment env) throws Exception {
		Value val = env.get(this);
		if (val == null)
			throw new Exception(printName + " is undefined");
		return val;
	}
}

/*
 * An environment is a linked list of maps
 */
class Environment extends HashMap<Name, Value> {
	private Environment next;

	public Environment(Environment next) {
		this.next = next;
	}

	public Environment() {
		this(null);
	}

	public Environment getNext() {
		return next;
	}

	public Value get(Name name) {
		if (this.containsKey(name)) {
			return super.get(name);
		} else {
			if (next == null) {
				return null;
			} else {
				return next.get(name);
			}
		}
	}
}

class Declaration implements Expression {
	private Name name;
	private Expression body;

	public Declaration(Name name, Expression exp) {
		this.name = name;
		this.body = exp;
	}

	public Value execute(Environment env) throws Exception {
		env.put(this.name, this.body.execute(env));
		return null; // for now
	}
}

class Function implements Value {
	private List<Name> parameters;
	private Expression body;

	public Function(Expression body, List<Name> params) {
		this.body = body;
		this.parameters = params;
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		if (parameters.size() != arguments.size())
			throw new Exception("parameter-argument mismatch");
		Environment tempEnv = new Environment(callingEnv);
		for (int i = 0; i < parameters.size(); i++) {
			tempEnv.put(parameters.get(i), arguments.get(i));
		}
		return body.execute(tempEnv);
	}
}

// example of a primitive or pre-defined function, also mul, sub, and, or, not
class AddFunction extends Function {
	public AddFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Number result = new Number(0.0);
		for (Value val : arguments) {
			if (val instanceof Number) {
				Number num = (Number) val;
				result = result.add(num);
			} else {
				throw new Exception("only numbers can be added");
			}
		}
		return result;
	}
}

class SubFunction extends Function {
	public SubFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Number result = new Number(0.0);
		boolean firstOperand = true;
		for (Value val : arguments) {
			if (val instanceof Number) {
				Number num = (Number) val;
				if (firstOperand) {
					result = num;
					firstOperand = false;
				} else {
					result = result.sub(num);
				}
			} else {
				throw new Exception("only numbers can be subtracted");
			}
		}
		return result;
	}
}

class MulFunction extends Function {
	public MulFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Number result = new Number(1.0);
		for (Value val : arguments) {
			if (val instanceof Number) {
				Number num = (Number) val;
				result = result.mul(num);
			} else {
				throw new Exception("only numbers can be multiplied");
			}
		}
		return result;
	}
}

class DivFunction extends Function {
	public DivFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Number result = new Number(0.0);
		boolean firstOperand = true;
		for (Value val : arguments) {
			if (val instanceof Number) {
				Number num = (Number) val;
				if (firstOperand) {
					result = num;
					firstOperand = false;
				} else {
					result = result.div(num);
				}
			} else {
				throw new Exception("only numbers can be divided");
			}
		}
		return result;
	}
}

class AppendFunction extends Function {
	public AppendFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Text result = new Text("");
		boolean firstOperand = true;
		for (Value val : arguments) {
			if (val instanceof Text) {
				Text text = (Text) val;
				if (firstOperand) {
					result = text;
					firstOperand = false;
				} else {
					result = result.append(text);
				}
			} else {
				throw new Exception("only texts can be appended");
			}
		}
		return result;
	}
}

class AndFunction extends Function {
	public AndFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Boole result = new Boole(false);
		boolean firstOperand = true;
		for (Value val : arguments) {
			if (val instanceof Boole) {
				Boole boole = (Boole) val;
				if (firstOperand) {
					result = boole;
					firstOperand = false;
				} else {
					result = result.and(boole);
				}
			} else {
				throw new Exception("only booleans can use this function");
			}
		}
		return result;
	}
}

class OrFunction extends Function {
	public OrFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Boole result = new Boole(false);
		boolean firstOperand = true;
		for (Value val : arguments) {
			if (val instanceof Boole) {
				Boole boole = (Boole) val;
				if (firstOperand) {
					result = boole;
					firstOperand = false;
				} else {
					result = result.or(boole);
				}
			} else {
				throw new Exception("only booleans can use this function");
			}
		}
		return result;
	}
}

/**
 * I asked another student that went to your office hours that he said the
 * NotFunction should be the same as the AddFunction in structure, so I kept it
 * the same.
 * 
 * However, shouldn't the NotFunction only take 1 parameter and negate the 1
 * boolean as the parameter?
 * 
 */
class NotFunction extends Function {
	public NotFunction() {
		super(null, null);
	}

	public Value apply(List<Value> arguments, Environment callingEnv) throws Exception {
		Boole result = new Boole(false);
		for (Value val : arguments) {
			if (val instanceof Boole) {
				Boole boole = (Boole) val;
				result = boole.not();
			} else {
				throw new Exception("only booleans can use this function");
			}
		}
		return result;
	}

	/*
	public Value applyV2(List<Value> arguments, Environment callingEnv) throws Exception {
		if (arguments.size() != 1) {
			throw new Exception("there should only be 1 parameter for the NotFunction");
		}
		try {
			Boole bool = (Boole) arguments.get(0);
			return bool.not();
		} catch (Exception e) {
			throw new Exception("only booleans can use this function");
		}
	}
	*/
}

// add(add(3, 4), pi) for example
class FunCall implements Expression {
	private Name operator; // name of a function, such as add
	private List<Expression> operands;

	public FunCall(Name operator, List<Expression> operands) {
		this.operator = operator;
		this.operands = operands;
	}

	// Blueprint listed.
	public Value execute(Environment env) throws Exception {
		Function f;
		try {
			f = (Function) operator.execute(env);
		} catch (Exception e) {
			throw new Exception(operator + " is not a function");
		}
		List<Value> args = new ArrayList<Value>();
		for (Expression ex : this.operands) {
			args.add(ex.execute(env));
		}
		return f.apply(args, env);
	}
}

class Console {
	private Scanner kbd = new Scanner(System.in);
	private Environment globalEnv = new Environment();

	private List<String> scan(String exp) {
		Scanner line = new Scanner(exp);
		List<String> tokens = new ArrayList<String>();
		while (line.hasNext()) {
			tokens.add(line.next());
		}
		return tokens;
	}

	// for now:
	private Expression parse(List<String> tokens) {
		return null;
	}

	public void repl() {
		List<String> tokens;
		while (true) {
			try {
				tokens = new ArrayList<String>();
				System.out.print("-> ");
				String input = kbd.nextLine();
				if (input.equals("quit")) {
					break;
				}
				Expression exp = parse(scan(input));
				Value val = exp.execute(globalEnv);
				System.out.println("result = " + val);
			} catch (Exception e) {
				System.out.println("Error, " + e.getMessage());
			}

		}
		System.out.println("bye");
	}
}

public class Cranberry {
	public static void main(String args[]) {
		// Console console = new Console();
		// console.repl();

		try {
			// General testing
			Environment globalEnv = new Environment();
			Name pi = new Name("pi");
			Number num = new Number(3.14);
			Declaration dec = new Declaration(pi, num);
			dec.execute(globalEnv);
			System.out.println("pi = " + pi.execute(globalEnv));
			System.out.println("num = " + num.execute(globalEnv));
			Name x = new Name("x");
			Number two = new Number(2.0);
			Declaration dec2 = new Declaration(x, two);
			dec2.execute(globalEnv);
			System.out.println("x = " + x.execute(globalEnv));

			System.out.println();

			// FunCall testing.
			Name add = new Name("add");
			Name mul = new Name("mul");
			Name div = new Name("div");
			Name sub = new Name("sub");
			globalEnv.put(add, new AddFunction());
			globalEnv.put(mul, new MulFunction());
			globalEnv.put(div, new DivFunction());
			globalEnv.put(sub, new SubFunction());

			// MulFunction
			List<Expression> mulOperands = new ArrayList<Expression>();
			mulOperands.add(two);
			mulOperands.add(new Number(3.0));
			FunCall mulFunCall = new FunCall(mul, mulOperands);
			Name mulEx = new Name("mulEx");
			Declaration dec3 = new Declaration(mulEx, mulFunCall);
			dec3.execute(globalEnv);
			System.out.println("mul(x, 3.0) = " + mulEx.execute(globalEnv));

			// AddFunction
			List<Expression> addOperands = new ArrayList<Expression>();
			addOperands.add(mulEx);
			addOperands.add(new Number(10.0));
			FunCall addFunCall = new FunCall(add, addOperands);
			Name addEx = new Name("mulEx");
			Declaration dec4 = new Declaration(addEx, addFunCall);
			dec4.execute(globalEnv);
			System.out.println("add(mul(x, 3.0), 10) = " + addEx.execute(globalEnv));

			// DivFunction
			List<Expression> divOperands = new ArrayList<Expression>();
			divOperands.add(addEx);
			divOperands.add(new Number(4.0));
			FunCall divFunCall = new FunCall(div, divOperands);
			Name divEx = new Name("divEx");
			Declaration dec5 = new Declaration(divEx, divFunCall);
			dec5.execute(globalEnv);
			System.out.println("div(add(mul(x, 3.0), 10), 4) = " + divEx.execute(globalEnv));

			// SubFunction
			List<Expression> subOperands = new ArrayList<Expression>();
			subOperands.add(divEx);
			subOperands.add(new Number(8.0));
			subOperands.add(new Number(8.0));
			FunCall subFunCall = new FunCall(sub, subOperands);
			Name subEx = new Name("divEx");
			Declaration dec6 = new Declaration(subEx, subFunCall);
			dec6.execute(globalEnv);
			System.out.println("sub(div(add(mul(x, 3.0), 10), 4), 8, 8) = " + subEx.execute(globalEnv));

			System.out.println();

			// Text testing
			Name append = new Name("append");
			globalEnv.put(append, new AppendFunction());

			Text t1 = new Text("Killer Queen");
			Text t2 = new Text(" Bites");
			Text t3 = new Text(" The Dust");
			List<Expression> textOperands = new ArrayList<Expression>();
			textOperands.add(t1);
			textOperands.add(t2);
			textOperands.add(t3);
			FunCall appendFunCall = new FunCall(append, textOperands);
			Name appendEx = new Name("appendEx");
			Declaration dec7 = new Declaration(appendEx, appendFunCall);
			dec7.execute(globalEnv);
			System.out.println("Appended text: " + appendEx.execute(globalEnv));

			// Boole testing
			Name and = new Name("and");
			Name or = new Name("or");
			Name not = new Name("not");
			globalEnv.put(and, new AndFunction());
			globalEnv.put(or, new OrFunction());
			globalEnv.put(not, new NotFunction());
			Name true1 = new Name("true1");
			Name true2 = new Name("true2");
			Name false1 = new Name("false1");
			Name false2 = new Name("false2");
			Boole bool1 = new Boole(true);
			Boole bool2 = new Boole(true);
			Boole bool3 = new Boole(false);
			Boole bool4 = new Boole(false);
			Declaration dec8 = new Declaration(true1, bool1);
			Declaration dec9 = new Declaration(true2, bool2);
			Declaration dec10 = new Declaration(false1, bool3);
			Declaration dec9999 = new Declaration(false2, bool4);
			dec8.execute(globalEnv);
			dec9.execute(globalEnv);
			dec10.execute(globalEnv);
			dec9999.execute(globalEnv);

			List<Expression> orOperands = new ArrayList<Expression>();
			orOperands.add(true1);
			orOperands.add(false1);
			FunCall orFunCall = new FunCall(or, orOperands);
			Name orEx = new Name("orEx");
			Declaration dec11 = new Declaration(orEx, orFunCall);
			dec11.execute(globalEnv);
			List<Expression> andOperands = new ArrayList<Expression>();
			andOperands.add(true2);
			andOperands.add(orFunCall);
			FunCall andFunCall = new FunCall(and, andOperands);
			Name andEx = new Name("andEx");
			Declaration dec12 = new Declaration(andEx, andFunCall);
			dec12.execute(globalEnv);
			System.out.println("and(true, or(true, false)): " + andEx.execute(globalEnv));

			List<Expression> notOperands = new ArrayList<Expression>();
			notOperands.add(orFunCall);
			FunCall notFunCall = new FunCall(not, notOperands);
			Name notEx = new Name("notEx");
			Declaration dec13 = new Declaration(notEx, notFunCall);
			dec13.execute(globalEnv);
			System.out.println("not(and(true, or(true, false))): " + notEx.execute(globalEnv));

		} catch (Exception e) {
			System.err.println(e);
		}
	}
}