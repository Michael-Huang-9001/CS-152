import Array._

object MatrixCalculator {

  // converts matrix to a string
  def toString(matrix: Array[Array[Int]]) = {
    // place code here
    var string = "\n\n"
    for (i <- 0 until matrix.length) {
      for (j <- 0 until matrix(0).length) {
        string += matrix(i)(j)
        if (j == matrix(0).length - 1) {
          string += "\n"
        } else {
          string += " "
        }
      }
    }
    string
  }

  // returns the sum of the diagonal entries of a matrix
  def trace(m: Array[Array[Int]]) = {
    // place code here
    var trace = 0
    for(i <- 0 until m.length) {
      trace += m(i)(i)
    }
    trace
  }

  // returns a dim x dim matrix with i/j entry = 3 * i + 2 * j % cap
  def makeArray(dim: Int, cap: Int = 100) = {
    // place code here
    var matrix = ofDim[Int](dim, dim)
    for (i <- 0 until dim) {
      for (j <- 0 until dim) {
        matrix(i)(j) = 3 * i + 2 * j % cap
      }
    }
    matrix
  }

  def main(args: Array[String]): Unit = {
    print("Enter a positive integer: ")
    var n = readInt
    var m = makeArray(n)
    println(toString(m))
    println("trace = " + trace(m))
  }
}