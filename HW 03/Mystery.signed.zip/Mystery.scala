/*
public class Mystery {
   public static void main(String args[]) {
      for(int i = 0; i < 10; i++) {
         for(int j = 0; j < 10; j++) {
            if ((i + j) % 10 == 3) continue;
            if (i + j == 15) break;
            System.out.println("i = " + i + ", j = " + j);
         }
      }
   }
}
*/

import util.control._

object Mystery {

  def main(args: Array[String]): Unit = {
    // Enter code here
    var inner = new Breaks
    var outer = new Breaks
    for (i <- 0 until 10) {
      outer.breakable {
        for (j <- 0 until 10) {
          inner.breakable {
            if ((i + j) % 10 == 3) {
              inner.break
            }
            if (i + j == 15) {
              outer.break
            }
            println("i = " + i + ", j = " + j)
          }
        }
      }
    }
  }
}