object ShapeMaker {

  def makeRectangle(rows: Int, cols: Int) = {
    // place implementation here
    var result = ""
    for (i <- 1 to cols) {
      for (j <- 1 to rows) {
        result += "*"
      }
      result += "\n"
    }
    result
  }

  def makeRightTriangle(rows: Int) = {
    // place implementation here
    var result = ""
    for (i <- 1 to rows) {
      for (j <- 1 to i) {
        result += "*"
      }
      result += "\n"
    }
    result
  }

  def makeIsoTriangle(rows: Int) = {
    // place implementation here
    var mid = rows / 2
    var result = ""
    var space = mid
    var stars = 0
    while(space >= 0) {
      for(i <- 0 until space) {
        result += " "
      }
      space -= 1
      for (i <- 0 until stars) {
        result += "*"
      }
      result += "*"
      for (i <- 0 until stars) {
        result += "*"
      }
      stars += 1
      result += "\n"
    }
    result
  }

  def makeInvertedTriangle(rows: Int) = {
    // place implementation here
    var mid = rows / 2
    var result = ""
    var space = 0
    var stars = mid
    while(stars >= 0) {
      for(i <- 0 until space) {
        result += " "
      }
      space += 1
      for (i <- 0 until stars) {
        result += "*"
      }
      result += "*"
      for (i <- 0 until stars) {
        result += "*"
      }
      stars -= 1
      result += "\n"
    }
    result
  }

  def main(args: Array[String]): Unit = {
    print("Enter a positive integer: ")
    var n = readInt
    println(makeRectangle(n, n))
    println(makeRightTriangle(n))
    println(makeIsoTriangle(n))
    println(makeInvertedTriangle(n))
  }

}