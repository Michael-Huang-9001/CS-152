package values

trait Value extends Serializable {
  
}