package ui
import expressions._
import values._

class JediException(val gripe: String = "error!") extends Exception {
  
}