package ui
import expressions._
import values._

object testDriver {
  
  def main(args: Array[String]): Unit = {
    Number.test
    Boole.test
  }
}